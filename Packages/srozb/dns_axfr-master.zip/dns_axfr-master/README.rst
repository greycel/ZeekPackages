DNS AXFR
--------

This package notices every dns axfr query sent from external network.

This type of traffic indicates usage of fierce3/dnsenum tool to gain
basic info about your dns zone configuration. It's a part of reconnaissance
conducted before network exploitation.

