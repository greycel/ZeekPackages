# bro-large_uploads

Raises notices on any large uploads to the Internet and emails alerts on sufficiently large uploads if enabled.

Source must be a local net and destination must not be a local net.

Will also raise alerts on multiple large uploads seen from the same source IP in Y amount of time.

Endeavors to do an asynochronous reverse DNS lookup on source and destination IPs.
